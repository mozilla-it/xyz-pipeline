# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pipeline',
 'pipeline.api',
 'pipeline.tests',
 'pipeline.tests.bdd',
 'pipeline.tests.bdd.steps',
 'pipeline.tests.resources']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cloudpipeline',
    'version': '0.1.2',
    'description': 'Generic Pipeline Mechanism',
    'long_description': None,
    'author': 'Adam Frank',
    'author_email': 'afrank@mozilla.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7',
}


setup(**setup_kwargs)
